 ✋Say "Hi" to me Here!!
************************
❣Instagram : https://instagram.com/parasu_servai_da

❣Facebook  : https://www.facebook.com/parasuraman.mass.5

❣Telegram  : https://t.me/pk_red_dark_1

❣E-Mail ID : parasuparasu51@gmail.com

❣LINKEDIN : https://www.linkedin.com/in/parasu-raman-74a86031b/

❣E-Mail ID :

❣E-Mail ID :

🔔Subscribe to channel for more videos: 
https://youtube.com/channel/UC6vP9taiYAP4FoJKQR9jCdA

❣link

Disclaimer
This channel does not promote or encourage any illegal activities. 

All contents provided by this channel  for GENERAL AND EDUCATIONAL PURPOSE ONLY.

Copyright disclaimer under section 107 of the copyright act 1976,allowance is made for "fair use policy" for purposes such as criticism, comment, news reporting, teaching, scholarship and research. Fair use is a use permitted by copyright statute that might otherwise be infringing. Non-profit, educational or personal use tips the balance in favor of fair use.
